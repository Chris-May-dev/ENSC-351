//============================================================================
//
//% Student Name 1: Christopher Robert May
//% Student 1 #: 301319469
//% Student 1 userid (cmay): stu1 (cmay@sfu.ca)
//
//% Student Name 2: Forbes Kwun Fung Ng
//% Student 2 #: 301278865
//% Student 2 userid (forbesn): stu2 (forbesn@sfu.ca)
//
//% Below, edit to list any people who helped you with the code in this file,
//%      or put 'None' if nobody helped (the two of) you.
//
// Helpers: _everybody helped us/me with the assignment (list names or put 'None')__
//
//      TA: Zavier Patrick Aguila, Maryamsadat RasouliDanesh
//      Students: Antonio Kim, Matthew Chute
//
// Also, list any resources beyond the course textbooks and the course pages on Piazza
// that you used in making your submission.
//
// Resources:  ___________
//              http://man7.org/linux/man-pages/man2/recv.2.html#targetText=The%20recv()%2C%20recvfrom(),the%20differences%20between%20the%20calls.
//
//%% Instructions:
//% * Put your name(s), student number(s), userid(s) in the above section.
//% * Also enter the above information in other files to submit.
//% * Edit the "Helpers" line and, if necessary, the "Resources" line.
//% * Your group name should be "P2_<userid1>_<userid2>" (eg. P1_stu1_stu2)
//% * Form groups as described at:  https://courses.cs.sfu.ca/docs/students
//% * Submit files to courses.cs.sfu.ca
//
// Version     : September, 2019
// Copyright   : Copyright 2019, Craig Scratchley
// Description : Starting point for ENSC 351 Project Part 2
//============================================================================


#include <unistd.h>         // for read/write/close
#include <fcntl.h>          // for open/creat
#include <thread>
#include <mutex>
#include <iostream>
#include <vector>
#include <condition_variable>
#include <sys/types.h>
#include <sys/socket.h>         // for socketpair
#include "SocketReadcond.h"
#include "AtomicCOUT.h"

class sktPr {
public:
    sktPr();
    sktPr(int MP);
    int myPair;
    int cntr;  //any time somebody writes to your socket, this counter will increase. Every time you read from your socket, the counter will decrease.
    std::mutex cntrMTX; // this is lock such that writers can write to this socket if this MTX is locked
    std::mutex emptyMTX; // this is the lock such that readers can notify TCDrainers to check the empty condition again
    std::condition_variable cntr_cond;
    std::condition_variable empty_cond;
    bool isEmpty();
private:
};

sktPr::sktPr()
{
    cntr = 0;
    myPair = 0;
}

sktPr::sktPr(int MP)
{
    cntr = 0;
    myPair = MP; // set the socket pair value
}
bool sktPr::isEmpty()
{
    return (cntr <= 0);
}

typedef std::shared_ptr <sktPr> myThing;
typedef std::vector <myThing> sktVctr; // Global vector to hold elements of type (myThing)
std::mutex vectLck;  //global mutex used for locking when creating socket pairs
sktVctr myVect(5);


int mySocketpair( int domain, int type, int protocol, int des[2] )
{
    std::unique_lock <std::mutex> globalLck (vectLck);
    int returnVal = socketpair(domain, type, protocol, des);
    unsigned value1 = des[0];
    unsigned value2 = des[1];
    unsigned maxValue = 0;
    if (value1 > value2)
    {
        maxValue = value1;
    }
    else
    {
        maxValue = value2;
    }
    if(myVect.capacity()<=maxValue)
    {
        myVect.resize(maxValue+1); //resize vector to make vector of size  maxValue +1
    }
    myVect[value1]= std::make_shared<sktPr>(value2);
    myVect[value2]= std::make_shared<sktPr>(value1);
    return returnVal;
}

int myOpen(const char *pathname, int flags, mode_t mode)
{
    std::unique_lock <std::mutex> Globallck (vectLck);
    std::unique_lock <std::mutex> lck (vectLck);
    //std::cout << "opening******";
    int myReturn = open(pathname, flags, mode);
    if(myReturn >= myVect.capacity())
    {
        myVect.resize(myReturn + 1);
    }
    return myReturn;
}

int myCreat(const char *pathname, mode_t mode)
{

    std::unique_lock <std::mutex> Globallck (vectLck);
    int creatVar = creat(pathname, mode);

    if(creatVar >= myVect.capacity())
    {
        myVect.resize(creatVar+1); //resize vector to make vector of size  maxValue +1
    }
    //std::cout << "creat ing******";
    return creatVar;
}

ssize_t myWrite( int des, const void* buf, size_t nbyte )
{
    //std::unique_lock<std::mutex> Globallck  (vectLck);
    // Hello! I would like to write to my pair's socket. My socket is Des
    unsigned mySpot = (unsigned)des;
    ssize_t myReturn;
    if(myVect[mySpot]== nullptr) //if des IS a file and NOT a socket
    {
         myReturn = write(des,buf,nbyte);
     //    std::cout << "WritingToFile " << nbyte <<" "<< myReturn <<" "<< des <<std::endl;
    }
    else //if des IS a socket and NOT a file
    {
        unsigned myPair = myVect[mySpot]->myPair; // find the pair of des
        //std::cout<<"cntr:" << myVect[myPair]->cntr <<std::endl;
        std::unique_lock <std::mutex> lck (myVect[myPair]->cntrMTX);  // This line locks the mutex found at sktVctr[mySpot] to keep track of the socket pair you are using
        myReturn = write(des,buf,nbyte); //write to the descriptors pair (myPair)
        if(myReturn!=-1)
        {
            myVect[myPair]->cntr +=  myReturn; //
            //std::cout << "WritingToSocket nbyte:" << nbyte <<" myReturn:"<< myReturn <<" des:"<<des<<" cntr:" << myVect[myPair]->cntr <<std::endl; // cout what has done
            myVect[myPair]->empty_cond.notify_all(); //this will be used for the case where the reader was trying to read from its socket but didnt get enough data.
            //std::cout << " Notified myPairs empty_cond " <<  " " << myPair <<std::endl;
        }

    }
    return myReturn;
}
int myReadcond(int des, void * buf, int n, int min, int time, int timeout)
{
    int myReturn;
    unsigned mySpot = (unsigned)des;
    if(min == 0) //Utilized by dumpGlitches from socket
    {
        std::unique_lock<std::mutex> lck  (myVect[mySpot]->cntrMTX);
        return wcsReadcond(mySpot, buf, n, min, time, timeout);
    }
    if(myVect[mySpot]== nullptr) //read FROM file
    {
        ssize_t mynewReturn = read(des,buf,n);
    //    std::cout << "ReadingFromFile "<< n <<" "<< mynewReturn <<" "<< des  <<std::endl;
        return mynewReturn;
    }
    else // read FROM des
    {
        std::unique_lock<std::mutex> lck  (myVect[mySpot]->cntrMTX);
        if(myVect[mySpot]->cntr < min )
        {
            //std::cout << "Waiting for more data " << myVect[mySpot]->cntr <<" < "<< min << " " <<des << std::endl;
            myVect[mySpot]->cntr -= min ; // Gives the illusion of empty socket so TCDrain can progress
            myVect[mySpot]->empty_cond.notify_all();
            myVect[mySpot]->empty_cond.wait(lck,[mySpot]{return (  myVect[mySpot]->cntr >= 0  || myVect[mySpot]->myPair == -1 ) ;});
            //std::cout << "got more data "<< des <<std::endl;
        }
        if(myVect[mySpot]->myPair == -1)
        {
            myReturn = wcsReadcond(mySpot, buf, n , myVect[mySpot]->cntr , time, timeout);
            myVect[mySpot]->cntr = 0;
            //std::cout << "Partner closed";
            return myReturn;
        }
        myReturn = wcsReadcond(mySpot, buf, n , min , time, timeout);
        myVect[mySpot]->cntr = 0;
        //std::cout << "ReadingFromSocket n:"<< n <<" myReturn:"<< myReturn <<" des:"<< des << " cntr:"<<myVect[mySpot]->cntr <<std::endl;
        if(myVect[mySpot]->cntr == 0)
        {
            //std::cout << "cntr is empty:" << mySpot << std::endl;
            myVect[mySpot]->empty_cond.notify_all();
        }
        return myReturn;
     }
     return -1;
}

int myTcdrain(int des)
{
    unsigned mySpot = (unsigned)des;
    int temp = myVect[mySpot]->myPair;
    if (temp != -1)
    {
        int myPair = myVect[mySpot]->myPair;
        if(myVect[myPair]->cntr > 0)
        {
            //std::cout << "I'ma wait now: " << des<<std::endl;
            std::unique_lock <std::mutex> lck (myVect[myPair]->cntrMTX);
            myVect[myPair]->empty_cond.wait(lck,[myPair]{return myVect[myPair]->isEmpty();});
            //std::cout << "Done waiting now: " << des<<std::endl;
            lck.unlock();
        }
        else
        {
          //bstd::cout << "Already drained" << std::endl;
        }
    }

    myVect[mySpot]->empty_cond.notify_all();
    return 0;
}


int myClose( int fd )
{
    std::unique_lock <std::mutex> Globallck (vectLck);
    //std::cout << "closing******: " <<fd << std::endl;
    unsigned myPair = myVect[fd]->myPair;
    if (myVect[fd] !=nullptr)
    {
        if ( myVect[myPair] !=nullptr)
        {
            myTcdrain(fd); // use this function to make sure the partner reads all the data before closing.
            myVect[myPair]->myPair = -1;
            myVect[myPair]->empty_cond.notify_all();
            myVect[myPair]->cntr_cond.notify_all();
            //delete myVect[fd];
        }
    }
    return close(fd);
}

ssize_t myRead( int des, void* buf, size_t nbyte)
{
    // deal with reading from descriptors for files
    // myRead (for our socketpairs) reads a minimum of 1 byte
    return myReadcond(des, buf, nbyte, 1, 0, 0);
}
