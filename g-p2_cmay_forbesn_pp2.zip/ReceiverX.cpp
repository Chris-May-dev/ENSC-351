//============================================================================
//
//% Student Name 1: student1
//% Student 1 #: 123456781
//% Student 1 userid (email): stu1 (stu1@sfu.ca)
//
//% Student Name 2: student2
//% Student 2 #: 123456782
//% Student 2 userid (email): stu2 (stu2@sfu.ca)
//
//% Below, edit to list any people who helped you with the code in this file,
//%      or put 'None' if nobody helped (the two of) you.
//
// Helpers: _everybody helped us/me with the assignment (list names or put 'None')__
//
// Also, list any resources beyond the course textbooks and the course pages on Piazza
// that you used in making your submission.
//
// Resources:  ___________
//
//%% Instructions:
//% * Put your name(s), student number(s), userid(s) in the above section.
//% * Also enter the above information in other files to submit.
//% * Edit the "Helpers" line and, if necessary, the "Resources" line.
//% * Your group name should be "P2_<userid1>_<userid2>" (eg. P1_stu1_stu2)
//% * Form groups as described at:  https://courses.cs.sfu.ca/docs/students
//% * Submit files to courses.cs.sfu.ca
//
// File Name   : ReceiverX.cpp
// Version     : September 3rd, 2019
// Description : Starting point for ENSC 351 Project Part 2
// Original portions Copyright (c) 2019 Craig Scratchley  (wcs AT sfu DOT ca)
//============================================================================

#include <string.h> // for memset()
#include <fcntl.h>
#include <stdint.h>
#include <iostream>
#include "myIO.h"
#include "ReceiverX.h"
#include "VNPE.h"
#include "AtomicCOUT.h"
//using namespace std;

ReceiverX::
ReceiverX(int d, const char *fname, bool useCrc)
:PeerX(d, fname, useCrc), 
NCGbyte(useCrc ? 'C' : NAK),
goodBlk(false), 
goodBlk1st(false), 
syncLoss(true),
numLastGoodBlk(0)
{
}

void ReceiverX::receiveFile()
{
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	transferringFileD = PE2(myCreat(fileName, mode), fileName);

	// ***** improve this member function *****
	// below is just an example template.  You can follow a
	// 	different structure if you want.
	// inform sender that the receiver is ready and that the
	//		sender can send the first block

	sendByte(NCGbyte);
	numLastGoodBlk = 0;
	while(PE_NOT(myRead(mediumD, rcvBlk, 1), 1), (rcvBlk[0] == SOH))
	{
	    getRestBlk();
	    if (NCGbyte == 'C' || NCGbyte == NAK)
	    {
	        if(goodBlk)
	        {
	             sendByte(ACK);

                 if(goodBlk1st)
                 {
	                 writeChunk(); // write chunk to the output file
	                 numLastGoodBlk++;
                 }
	        }
            else
            {
                sendByte(NAK); // There was an error in transmission
            }

	    }

	};



	  /* checking eots!!! */

    // assume EOT was just read in the condition for the while loop
	if(rcvBlk[0]==CAN)
	{
	    result = "Sender Cancelled";
	    return;
	}
	else if(rcvBlk[0] == EOT)
	{
	    sendByte(NAK); // NAK the first EOT
	}
	else
	{
	    can8();
	    result = "unexpected char # " ;
	    return;
	}

	PE_NOT(myRead(mediumD, rcvBlk, 1), 1); // presumably read in another EOT


    if(rcvBlk[0] == EOT)
    {
        sendByte(ACK);  // ACK the second EOT
    }
    else if(rcvBlk[0]==CAN)
    {
        result = "Sender Cancelled";
        can8();

    }
    else
    {
        can8();
        result = "unexpected char # " ;
    }

	if(-1 == myClose(transferringFileD)){
	    result = "File can't close properly" ;
	}
	else
	{
	    result = "DONE"; //assume the file closed properly.
	}

	// check if the file closed properly.  If not, result should be something other than "Done".
}

bool ReceiverX::CheckSumCalc()
{
    // **** this function will need to be modified ****
    int temp = 0;
    for (int i = 3; i <= 130; i++)
    {
        temp = temp + rcvBlk[i];
    }
    while(temp>255)
    {
        temp -= 256;
    }
    if( temp == rcvBlk[131])
    {
       return true;
    }
    else
    {
        return false;
    }
}

bool ReceiverX::CRCCalc()
{
   uint16_t temp = 0;
   crc16ns(&temp, &rcvBlk[DATA_POS]);

   if (temp == *(uint16_t *)&rcvBlk[131])
   {
       return true;
   }
   else
   {
       return false;
   }
   //crc16ns((uint16_t*)&blkBuf[PAST_CHUNK], &blkBuf[DATA_POS])
}

/* Only called after an SOH character has been received.
The function tries
to receive the remaining characters to form a complete
block.  The member
variable goodBlk1st will be made true if this is the first
time that the block was received in "good" condition.
*/
void ReceiverX::getRestBlk()
{
	// ********* this function must be improved ***********
	if(NCGbyte == 'C')
	{
	    PE_NOT(myReadcond(mediumD, &rcvBlk[1], REST_BLK_SZ_CRC, REST_BLK_SZ_CRC, 0, 0), REST_BLK_SZ_CRC);
        if(CRCCalc())
        {
            goodBlk=true;
        }
        else
        {
            goodBlk=false;
        }
	}
	else if(NCGbyte == NAK)
	{
	    PE_NOT(myReadcond(mediumD, &rcvBlk[1], REST_BLK_SZ_CS, REST_BLK_SZ_CS, 0, 0), REST_BLK_SZ_CS);
        if(CheckSumCalc())
        {
            goodBlk=true;
        }
        else
        {
            goodBlk=false;
        }
	}

    if(rcvBlk[1] == numLastGoodBlk)
    {
        goodBlk1st=false;

    }
    else if(rcvBlk[1] == numLastGoodBlk+1)
    {
        goodBlk1st=true;

    }
}




//Write chunk (data) in a received block to disk
void ReceiverX::writeChunk()
{
	PE_NOT(write(transferringFileD, &rcvBlk[DATA_POS], CHUNK_SZ), CHUNK_SZ);
}
//Send 8 CAN characters in a row to the XMODEM sender, to inform it of
//	the canceling of a file transfer
void ReceiverX::can8()
{
	// no need to space CAN chars coming from receiver in time
    char buffer[CAN_LEN];
    memset(buffer, CAN, CAN_LEN);
    PE_NOT(myWrite(mediumD, buffer, CAN_LEN), CAN_LEN);
}
